rm *.dat
rm *.txt
